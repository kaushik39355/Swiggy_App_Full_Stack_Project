const content = {
  homePageTitle: 'Home Page',
  dashboardPageTitle: 'Dashboard Page',
};

export default content;
