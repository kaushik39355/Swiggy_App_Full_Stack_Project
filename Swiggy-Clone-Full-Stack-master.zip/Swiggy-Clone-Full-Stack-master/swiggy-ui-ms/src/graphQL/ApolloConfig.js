module.exports = {
  client: {
    name: 'Dummy service [web]',
    service: 'dummy-service',
  },
};
