export { default } from './RestaurantPage';
