export { default } from './Restaurant';
