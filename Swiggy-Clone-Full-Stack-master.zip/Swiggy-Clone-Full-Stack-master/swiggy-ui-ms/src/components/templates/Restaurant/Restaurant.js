/**
 *
 * Landing
 *
 */
import React, { Fragment} from 'react';
import PropTypes from 'prop-types';
const Landing = (props) => {

  return (
  <Fragment>
     <h1>Restaurant will open soon..</h1>
    </Fragment>
    );
};

export default Landing;
