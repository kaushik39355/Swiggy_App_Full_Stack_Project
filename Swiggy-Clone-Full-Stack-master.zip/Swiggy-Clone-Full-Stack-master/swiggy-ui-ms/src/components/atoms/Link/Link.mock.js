const defaultConfig = {};

export default defaultConfig;
