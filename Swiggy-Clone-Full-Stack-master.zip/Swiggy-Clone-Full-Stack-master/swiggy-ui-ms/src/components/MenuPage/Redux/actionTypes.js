export const ADD_CART_ITEM = "ADD_CART_ITEM";
export const INCREMENT_QTY = "INCREMENT_QTY";
export const DECREMENT_QTY = "DECREMENT_QTY";
export const EMPTY_CART = "EMPTY_CART";
