export { default } from './RestaurantCard';
