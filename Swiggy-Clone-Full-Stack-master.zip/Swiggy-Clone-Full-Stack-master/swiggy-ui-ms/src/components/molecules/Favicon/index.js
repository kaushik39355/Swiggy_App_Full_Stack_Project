export { default } from './Favicon';
