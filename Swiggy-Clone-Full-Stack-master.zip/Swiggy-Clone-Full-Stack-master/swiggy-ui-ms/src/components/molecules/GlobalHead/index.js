export { default } from './GlobalHead';
