export { default } from './RestaurantLanding';
