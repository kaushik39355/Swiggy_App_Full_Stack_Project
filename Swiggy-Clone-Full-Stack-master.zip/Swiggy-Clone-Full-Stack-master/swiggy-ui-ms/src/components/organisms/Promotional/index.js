export { default } from './Promotional';
