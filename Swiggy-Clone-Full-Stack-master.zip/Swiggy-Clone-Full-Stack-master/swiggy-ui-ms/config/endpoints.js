export const graphQLApiUri = 'https://48p1r2roz4.sse.codesandbox.io';

export default graphQLApiUri;
