export const ENTITY_FOUND = 'entity was found';
export const NO_ENTITY_FOUND = 'no entity was found';

export const PARAMETERS_FAILED_VALIDATION = 'parameters failed validation';

export const ENTITY_CREATED = 'entity was created';
export const ENTITY_MODIFIED = 'entity was modified';
export const ENTITY_DELETED = 'entity was deleted';

export const RESULTS_RETURNED = 'results were returned';
