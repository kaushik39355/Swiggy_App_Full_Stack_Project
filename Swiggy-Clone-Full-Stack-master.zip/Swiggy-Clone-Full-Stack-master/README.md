# Swiggy Clone Platform 

https://www.youtube.com/watch?v=VJFm8XRn6AU&list=PLIGDNOJWiL1-r0EBC_jnlL5-gIiRIOuwv&ab_channel=Codewithtkssharma

- App Architecture
![Swiggy](./diag/swiggy-clone.png)

- App Database Digram
- 
![Swiggy](./diag/erd.png)
![Swiggy](./diag/swiggy.png)


